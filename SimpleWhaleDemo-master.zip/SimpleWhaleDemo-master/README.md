# docker-whale

Run me : `docker run -p80:80 ushamandya/whale-example`

Build me: `docker build -t ushamandya/whale-example .`
